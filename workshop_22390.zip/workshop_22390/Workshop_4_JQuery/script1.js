

$(document).ready(function () {
    $("form[name='registration']").validate({

        rules: {
            fname: {
                required: true,
                minlength: 3
            },
            lname: {
                required: true,
                minlength: 3
            },
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 5
            }
        },
        messages: 
        {
            fname: {
                required: "Please enter your fisrt name",
                minlength: "Name should be at least 3 characters"
            },
            lname: {
                required: "Please enter your fisrt name",
                minlength: "Name should be at least 3 characters"
            },           
            password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 5 characters long"
            },
            email: {
               required: "Please enter a valid email address",
                email: "The email should be in the format: abc@domain.tld"
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
   /*  $('#btn').on('click', function() {
        $("#form").valid();
    }); */
});