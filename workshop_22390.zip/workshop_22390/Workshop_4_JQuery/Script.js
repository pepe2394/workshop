  
   $(document).ready(function ()
   {  $('#btn').click(function(){

  
 
	var fname = $('#fname').val();
	var lname = $('#lname').val();
	var email = $('#inputEmail').val();
	var password = $('#inputPassword').val();
	var cpassword = $('#confirmPassword').val(); 
	
	if(fname=='' || fname==null)
	{
		 
		$('#fname_error').html(" Please enter first name."); 
		return false
	}	 
	if(lname=='' || lname==null)
	{
		 
		$('#lname_error').html(" Please enter last name.");
		return false
	}
	if(email=='' || email==null)
	{
		$('#email_error').html(" Please enter email.");
		return false
	}
	let reg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;	
	if(!reg.test(email))
	{	
		console.log(email) ;
		$('#email_error').html(" Please enter valid email.");
		return false
	}
	 
	if(password=='' || password==null)
	{	 
		$('#password_error').html(" Please enter password.");
		return false
	}
 
	if(cpassword=='' || cpassword==null)
	{
		 
		$('#cpassword_error').html(" Please enter confirm password.");
		return false
	}
 
	if(password != cpassword)
	{		 
		$('#cpassword_error').html("Confirm password must be same as password.");
		return false
	}	 
	 
        alert("Your form is ready to submit.");
		return true;
		
})
})
//for product searching

$(document).ready(function()
{	$('#search').on('keyup',function()
    {
	    let searchkey=$(this).val().toLowerCase()
        $('.product').filter(function()
        {            
            $(this).toggle($(this).text().toLowerCase().indexOf(searchkey)>-1)

        })
    })
})


$(document).ready(function(){
    $('#btnp').click(function()
    {
        if($('#inputPassword').attr('type')==='password')
        {
            ($('#inputPassword').attr('type','text'))
        }
        else
        {           
            ($('#inputPassword').attr('type','password'))
        }
    })
})